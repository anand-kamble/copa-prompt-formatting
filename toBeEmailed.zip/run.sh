#!/bin/bash 
#
SRC_DIR="copa-ata"
ENTRY_FILE="main.py"

python $SRC_DIR/$ENTRY_FILE
